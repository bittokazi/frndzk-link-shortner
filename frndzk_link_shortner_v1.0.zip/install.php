<?php
include('frndzk_core_functions.php');
frndzk_frndzk_fzk_bk_da_boss_fzk();
?>