<?php
ob_start();
include('frndzk_core_functions.php');
frndzk_redirector();
ob_flush();
?>