<?php
ob_start();
include('frndzk_core_functions.php');
frndzk_inc_boom();
ob_flush();
?>